Welcome to ShulkerOS-EVO

The world's first cross platform, login operated, operating system!

Features:
-Run on any device, anywhere, without syncing

-Uses only 5 MB

-Download apps from a custom app store with thousands of options

-Can replace your own operating system

-Built in games with hundreds of hours of gameplay

-Fully functing email system for on the go or at home messaging

-App store sync so you can download and play your favorite games anywhere

-Web browser

-Bash terminal for easy programming

-Easy download and installation

Requires:
-Replit account
-5 MB of RAM

Installation Guide:

-Import Github file

-Run command:
run = "bash shulkeros++.sh"

-Run project

Enjoy!